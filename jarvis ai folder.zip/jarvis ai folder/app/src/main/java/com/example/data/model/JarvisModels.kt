package com.example.data.model

enum class JarvisState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

enum class LanguageMode(val code: String, val displayName: String, val nativeName: String) {
    AUTO("auto", "Auto-Detect", "स्वतः (Bilingual)"),
    ENGLISH("en", "English", "English (US)"),
    HINDI("hi", "Hindi", "हिन्दी (भारत)")
}

enum class VoiceProfile(
    val id: String,
    val displayName: String,
    val description: String,
    val defaultPitch: Float,
    val defaultSpeed: Float
) {
    JARVIS_CLASSIC(
        "jarvis_classic",
        "J.A.R.V.I.S. Classic",
        "Refined British cadence, balanced timbre",
        0.92f,
        1.05f
    ),
    FRIDAY_TACTICAL(
        "friday_tactical",
        "F.R.I.D.A.Y. Tactical",
        "Energetic, clear, high-speed tactical delivery",
        1.18f,
        1.12f
    ),
    EDITH_SECURITY(
        "edith_security",
        "E.D.I.T.H. Defense",
        "Precise, articulate, mid-range security tone",
        1.05f,
        1.00f
    ),
    BARITONE_ARMOR(
        "baritone_armor",
        "Heavy Armor Baritone",
        "Deep resonant bass for Mark 3 & Hulkbuster",
        0.72f,
        0.92f
    ),
    HINDI_AUTHENTIC(
        "hindi_authentic",
        "हिन्दी भारतीय स्वर (Desi)",
        "Natural Hindi cadence & melodic modulation",
        1.00f,
        1.02f
    ),
    CUSTOM_SYNTHESIS(
        "custom",
        "Custom Stark Spec",
        "User-calibrated pitch and rate levels",
        1.00f,
        1.00f
    )
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val hindiText: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isSpoken: Boolean = false,
    val toolTag: String? = null,
    val imageUri: String? = null
)

enum class MessageSender {
    USER,
    JARVIS,
    SYSTEM
}

data class DeviceTelemetry(
    val batteryPercent: Int = 85,
    val isCharging: Boolean = false,
    val chargingType: String = "Battery",
    val ramUsedMb: Long = 1840,
    val ramTotalMb: Long = 5800,
    val storageFreeGb: Long = 42,
    val networkStatus: String = "Online (Quantum-Link)",
    val deviceModel: String = "Stark Tech Interface",
    val arcReactorPowerPercent: Int = 98
)

data class TaskItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val category: String = "Stark Protocol",
    val isDone: Boolean = false,
    val priority: String = "High",
    val timestamp: Long = System.currentTimeMillis()
)

data class MemoryItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val key: String,
    val value: String,
    val category: String = "Personal Directive",
    val timestamp: Long = System.currentTimeMillis()
)
