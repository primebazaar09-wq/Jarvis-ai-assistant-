package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.model.LanguageMode
import com.example.data.model.VoiceProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceManager(
    private val context: Context,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onWakeWordDetected: (String) -> Unit
) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private val _availableVoiceNames = MutableStateFlow<List<String>>(emptyList())
    val availableVoiceNames: StateFlow<List<String>> = _availableVoiceNames.asStateFlow()

    var isContinuousWakeWordActive = false
    var customWakeWord = "Hey Jarvis"
    var isMuted = false
    var speechSpeed = 1.05f
    var speechPitch = 0.95f
    var voiceProfile: VoiceProfile = VoiceProfile.JARVIS_CLASSIC
    var selectedVoiceName: String? = null
    var languageMode: LanguageMode = LanguageMode.AUTO

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                queryAvailableVoices()
                configureTtsLanguage(LanguageMode.AUTO)
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            }
        }
    }

    private fun queryAvailableVoices() {
        val tts = textToSpeech ?: return
        try {
            val voices = tts.voices
            if (!voices.isNullOrEmpty()) {
                val names = voices
                    .filter { !it.isNetworkConnectionRequired }
                    .map { it.name }
                    .sorted()
                _availableVoiceNames.value = names
            }
        } catch (_: Exception) {}
    }

    fun applyVoiceProfile(profile: VoiceProfile) {
        voiceProfile = profile
        if (profile != VoiceProfile.CUSTOM_SYNTHESIS) {
            speechPitch = profile.defaultPitch
            speechSpeed = profile.defaultSpeed
        }
        val tts = textToSpeech ?: return
        tts.setPitch(speechPitch)
        tts.setSpeechRate(speechSpeed)
    }

    fun setPitch(pitch: Float) {
        speechPitch = pitch.coerceIn(0.5f, 2.0f)
        textToSpeech?.setPitch(speechPitch)
    }

    fun setSpeed(speed: Float) {
        speechSpeed = speed.coerceIn(0.5f, 2.0f)
        textToSpeech?.setSpeechRate(speechSpeed)
    }

    fun setSelectedVoice(voiceName: String?) {
        selectedVoiceName = voiceName
        val tts = textToSpeech ?: return
        if (voiceName != null) {
            try {
                val matched = tts.voices?.firstOrNull { it.name == voiceName }
                if (matched != null) {
                    tts.voice = matched
                }
            } catch (_: Exception) {}
        }
    }

    fun configureTtsLanguage(mode: LanguageMode, textSample: String = "") {
        val tts = textToSpeech ?: return
        val isHindi = mode == LanguageMode.HINDI || (mode == LanguageMode.AUTO && isTextHindi(textSample))
        val targetLocale = if (isHindi) Locale("hi", "IN") else Locale.US
        val res = tts.setLanguage(targetLocale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.ENGLISH
        }

        // Apply specific voice if matched to target locale
        if (!selectedVoiceName.isNullOrBlank()) {
            try {
                val voice = tts.voices?.firstOrNull { it.name == selectedVoiceName }
                if (voice != null && voice.locale.language == targetLocale.language) {
                    tts.voice = voice
                }
            } catch (_: Exception) {}
        }

        tts.setSpeechRate(speechSpeed)
        tts.setPitch(speechPitch)
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        if (isMuted || !isTtsInitialized) return
        stopListening()
        configureTtsLanguage(languageMode, text)
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "JARVIS_${System.currentTimeMillis()}")
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "JARVIS_UTTERANCE")
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        _isSpeaking.value = false
    }

    fun startListening(isWakeWordMode: Boolean = false) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition not available on this device.")
            return
        }

        stopSpeaking()
        stopListening()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(createListener(isWakeWordMode))
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

                val selectedLocale = when (languageMode) {
                    LanguageMode.HINDI -> "hi-IN"
                    LanguageMode.ENGLISH -> "en-US"
                    LanguageMode.AUTO -> "hi-IN,en-US"
                }
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLocale)
            }

            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            _isListening.value = false
            onError("Voice initialization failed: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        _isListening.value = false
        _rmsLevel.value = 0f
    }

    private fun createListener(isWakeWordMode: Boolean): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _rmsLevel.value = 0.1f
            }

            override fun onBeginningOfSpeech() {
                _rmsLevel.value = 0.5f
            }

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _rmsLevel.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _rmsLevel.value = 0.2f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _rmsLevel.value = 0f
                if (isWakeWordMode && isContinuousWakeWordActive) {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (isContinuousWakeWordActive) startListening(isWakeWordMode = true)
                    }, 500)
                } else if (!isWakeWordMode) {
                    onError("Voice recognition code: $error")
                }
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _rmsLevel.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""

                if (isWakeWordMode) {
                    if (checkWakeWordTrigger(text)) {
                        onWakeWordDetected(text)
                    } else if (isContinuousWakeWordActive) {
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                            if (isContinuousWakeWordActive) startListening(isWakeWordMode = true)
                        }, 400)
                    }
                } else {
                    _liveTranscript.value = text
                    if (text.isNotBlank()) {
                        onResult(text)
                    }
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull() ?: ""
                _liveTranscript.value = partial

                if (isWakeWordMode && checkWakeWordTrigger(partial)) {
                    stopListening()
                    onWakeWordDetected(partial)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    fun checkWakeWordTrigger(input: String): Boolean {
        if (input.isBlank()) return false
        val lower = input.lowercase().trim()
        val customLower = customWakeWord.lowercase().trim()

        if (customLower.isNotBlank() && lower.contains(customLower)) return true

        val defaultTriggers = listOf(
            "hey jarvis",
            "jarvis",
            "ok jarvis",
            "hello jarvis",
            "नमस्ते जार्विस",
            "जार्विस",
            "सुनो जार्विस",
            "हे जार्विस",
            "जारविस"
        )
        return defaultTriggers.any { lower.contains(it) }
    }

    private fun isTextHindi(text: String): Boolean {
        return text.any { it in '\u0900'..'\u097F' }
    }

    fun destroy() {
        stopListening()
        stopSpeaking()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
