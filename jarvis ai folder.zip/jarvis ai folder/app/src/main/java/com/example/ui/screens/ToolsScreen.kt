package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Task
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.example.ui.components.TtsConfigurationPanel
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LanguageMode
import com.example.ui.JarvisViewModel
import com.example.ui.components.StarkHudCard
import com.example.ui.components.StarkTelemetryChip

enum class ToolModule(val label: String, val icon: ImageVector) {
    TRANSLATION("Translation Studio", Icons.Default.Translate),
    TTS_CONFIG("Voice Synthesizer (TTS)", Icons.Default.RecordVoiceOver),
    CODE_STUDIO("Code Studio", Icons.Default.Code),
    TASKS("Tasks & Protocols", Icons.Default.Task),
    MEMORY("Memory Vault", Icons.Default.Memory),
    DIAGNOSTICS("Diagnostics & Hardware", Icons.Default.Build),
    SEARCH_KNOWLEDGE("Satellite Knowledge", Icons.Default.Search)
}

@Composable
fun ToolsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    var selectedModule by remember { mutableStateOf(ToolModule.TRANSLATION) }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // Module Selector Tabs
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ToolModule.values()) { module ->
                val isSelected = selectedModule == module
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isSelected) primaryColor else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(
                            1.dp,
                            if (isSelected) primaryColor else primaryColor.copy(alpha = 0.3f),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedModule = module }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("tool_tab_${module.name}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = module.icon,
                            contentDescription = module.label,
                            tint = if (isSelected) Color.Black else primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = module.label,
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Active Tool Module Content
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedModule) {
                ToolModule.TRANSLATION -> TranslationStudioModule(viewModel)
                ToolModule.TTS_CONFIG -> TtsConfigurationPanel(viewModel)
                ToolModule.CODE_STUDIO -> CodeStudioModule(viewModel)
                ToolModule.TASKS -> TasksModule(viewModel)
                ToolModule.MEMORY -> MemoryVaultModule(viewModel)
                ToolModule.DIAGNOSTICS -> DiagnosticsModule(viewModel)
                ToolModule.SEARCH_KNOWLEDGE -> SearchKnowledgeModule(viewModel)
            }
        }
    }
}

// --- 1. Translation Studio ---
@Composable
fun TranslationStudioModule(viewModel: JarvisViewModel) {
    var sourceText by remember { mutableStateOf("Good morning Sir, all defense satellites are in geosynchronous orbit.") }
    var translatedResult by remember { mutableStateOf("शुभ प्रभात सर, सभी रक्षा उपग्रह भू-समकालिक कक्षा में हैं।") }
    val primaryColor = MaterialTheme.colorScheme.primary

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            StarkHudCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(
                        text = "BILINGUAL NEURAL TRANSLATION (EN ⟷ HI)",
                        color = primaryColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = sourceText,
                        onValueChange = { sourceText = it },
                        modifier = Modifier.fillMaxWidth().testTag("trans_source_input"),
                        label = { Text("Source Text (English or Hindi)", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryColor,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                viewModel.processUserInput("Translate this precisely into natural Hindi: '$sourceText'")
                                translatedResult = "Translating with JARVIS neural language model..."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Translate to Hindi (हिन्दी)", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.processUserInput("Translate this precisely into polished English: '$sourceText'")
                                translatedResult = "Translating with JARVIS neural language model..."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("To English", color = primaryColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            StarkHudCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TRANSLATED TRANSMISSION",
                            color = primaryColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(
                            onClick = {
                                viewModel.voiceManager.speak(translatedResult)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Listen",
                                tint = primaryColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = translatedResult,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

// --- 2. Code Studio ---
@Composable
fun CodeStudioModule(viewModel: JarvisViewModel) {
    var codeSnippet by remember {
        mutableStateOf(
            """
def calculate_arc_reactor_flux(power_core, load_factor):
    # Stark Industries Mark 85 Core Formula
    resonant_freq = 432.8  # Megahertz
    quantum_yield = (power_core ** 1.5) * resonant_freq
    return quantum_yield / max(load_factor, 0.01)
""".trimIndent()
        )
    }
    val primaryColor = MaterialTheme.colorScheme.primary

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            StarkHudCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(
                        text = "NEURAL CODE ASSISTANT & SYNTAX STUDIO",
                        color = primaryColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = codeSnippet,
                        onValueChange = { codeSnippet = it },
                        modifier = Modifier.fillMaxWidth().height(160.dp).testTag("code_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryColor,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedTextColor = Color(0xFF81D4FA),
                            unfocusedTextColor = Color(0xFF81D4FA)
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.processUserInput("Explain this code and identify any potential bugs or performance bottlenecks:\n$codeSnippet")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Explain & Debug", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.processUserInput("Convert this code into clean, idiomatic Kotlin coroutine code:\n$codeSnippet")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Convert to Kotlin", color = primaryColor, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- 3. Tasks & Protocols ---
@Composable
fun TasksModule(viewModel: JarvisViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    var newTaskTitle by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(modifier = Modifier.fillMaxSize()) {
        StarkHudCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newTaskTitle,
                    onValueChange = { newTaskTitle = it },
                    modifier = Modifier.weight(1f).testTag("new_task_input"),
                    placeholder = { Text("New Stark directive / task...", fontSize = 12.sp, color = Color.Gray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryColor,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (newTaskTitle.isNotBlank()) {
                            viewModel.addTask(newTaskTitle)
                            newTaskTitle = ""
                        }
                    },
                    modifier = Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)).background(primaryColor)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Task", tint = Color.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(tasks, key = { it.id }) { task ->
                StarkHudCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = task.isDone,
                            onCheckedChange = { viewModel.toggleTask(task.id) },
                            colors = CheckboxDefaults.colors(checkedColor = primaryColor, checkmarkColor = Color.Black)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                color = if (task.isDone) Color.Gray else Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (task.isDone) FontWeight.Normal else FontWeight.SemiBold
                            )
                            Text(
                                text = "CATEGORY: ${task.category.uppercase()} // PRIORITY: ${task.priority.uppercase()}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(onClick = { viewModel.deleteTask(task.id) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// --- 4. Memory Vault ---
@Composable
fun MemoryVaultModule(viewModel: JarvisViewModel) {
    val memories by viewModel.memories.collectAsState()
    var newKey by remember { mutableStateOf("") }
    var newValue by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(modifier = Modifier.fillMaxSize()) {
        StarkHudCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text(
                    text = "NEURAL MEMORY VAULT // PERSONAL DIRECTIVES",
                    color = primaryColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = newKey,
                        onValueChange = { newKey = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Directive key (e.g. Clearance)", fontSize = 11.sp, color = Color.Gray) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedTextField(
                        value = newValue,
                        onValueChange = { newValue = it },
                        modifier = Modifier.weight(1.2f),
                        placeholder = { Text("Value (e.g. Stark Alpha)", fontSize = 11.sp, color = Color.Gray) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = {
                        if (newKey.isNotBlank() && newValue.isNotBlank()) {
                            viewModel.addMemory(newKey, newValue)
                            newKey = ""
                            newValue = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Store in Neural Memory", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(memories, key = { it.id }) { mem ->
                StarkHudCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${mem.key.uppercase()}: ${mem.value}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "CLASS: ${mem.category.uppercase()}",
                                color = primaryColor.copy(alpha = 0.7f),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(onClick = { viewModel.deleteMemory(mem.id) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// --- 5. Diagnostics & Hardware Integration ---
@Composable
fun DiagnosticsModule(viewModel: JarvisViewModel) {
    val telemetry by viewModel.telemetry.collectAsState()
    val primaryColor = MaterialTheme.colorScheme.primary

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            StarkHudCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STARK SYSTEM HARDWARE TELEMETRY",
                            color = primaryColor,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(
                            onClick = { viewModel.refreshTelemetry() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = primaryColor)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("DEVICE: ${telemetry.deviceModel}", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text("ARC REACTOR POWER: ${telemetry.arcReactorPowerPercent}%", color = primaryColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("BATTERY CAPACITY: ${telemetry.batteryPercent}% (${telemetry.chargingType})", color = Color(0xFF81D4FA), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text("RAM CONSUMPTION: ${telemetry.ramUsedMb} MB / ${telemetry.ramTotalMb} MB", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text("INTERNAL STORAGE: ${telemetry.storageFreeGb} GB Available", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text("NETWORK ARRAY: ${telemetry.networkStatus}", color = Color(0xFF00E676), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        item {
            StarkHudCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(
                        text = "ANDROID DEVICE INTEGRATION SHORTCUTS",
                        color = primaryColor,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = { viewModel.deviceManager.openAppOrSetting("camera") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "Camera", tint = primaryColor, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Camera", color = primaryColor, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.deviceManager.openAppOrSetting("wifi") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Wifi, contentDescription = "Wi-Fi", tint = primaryColor, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Wi-Fi Settings", color = primaryColor, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.deviceManager.openAppOrSetting("settings") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = primaryColor, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Settings", color = primaryColor, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- 6. Satellite Knowledge Search ---
@Composable
fun SearchKnowledgeModule(viewModel: JarvisViewModel) {
    var searchQuery by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(modifier = Modifier.fillMaxSize()) {
        StarkHudCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text(
                    text = "STARK SATELLITE KNOWLEDGE & WEB SEARCH",
                    color = primaryColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Query global intelligence network...", fontSize = 11.sp, color = Color.Gray) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (searchQuery.isNotBlank()) {
                                viewModel.processUserInput("Search and summarize recent intel regarding: $searchQuery")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Search", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
