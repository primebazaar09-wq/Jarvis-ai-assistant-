package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.LanguageMode
import com.example.data.model.MemoryItem
import com.example.data.model.TaskItem
import com.example.data.model.VoiceProfile
import com.example.ui.theme.JarvisThemeMode
import org.json.JSONArray
import org.json.JSONObject

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    var customWakeWord: String
        get() = prefs.getString("custom_wake_word", "Hey Jarvis") ?: "Hey Jarvis"
        set(value) = prefs.edit().putString("custom_wake_word", value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", true)
        set(value) = prefs.edit().putBoolean("wake_word_enabled", value).apply()

    var wakeWordSensitivity: Float
        get() = prefs.getFloat("wake_word_sensitivity", 0.75f)
        set(value) = prefs.edit().putFloat("wake_word_sensitivity", value).apply()

    var languageMode: LanguageMode
        get() {
            val code = prefs.getString("language_mode", LanguageMode.AUTO.name) ?: LanguageMode.AUTO.name
            return try { LanguageMode.valueOf(code) } catch (e: Exception) { LanguageMode.AUTO }
        }
        set(value) = prefs.edit().putString("language_mode", value.name).apply()

    var themeMode: JarvisThemeMode
        get() {
            val theme = prefs.getString("theme_mode", JarvisThemeMode.STARK_CYAN.name) ?: JarvisThemeMode.STARK_CYAN.name
            return try { JarvisThemeMode.valueOf(theme) } catch (e: Exception) { JarvisThemeMode.STARK_CYAN }
        }
        set(value) = prefs.edit().putString("theme_mode", value.name).apply()

    var speechSpeed: Float
        get() = prefs.getFloat("speech_speed", 1.05f)
        set(value) = prefs.edit().putFloat("speech_speed", value).apply()

    var speechPitch: Float
        get() = prefs.getFloat("speech_pitch", 0.95f)
        set(value) = prefs.edit().putFloat("speech_pitch", value).apply()

    var voiceProfile: VoiceProfile
        get() {
            val name = prefs.getString("voice_profile", VoiceProfile.JARVIS_CLASSIC.name) ?: VoiceProfile.JARVIS_CLASSIC.name
            return try { VoiceProfile.valueOf(name) } catch (e: Exception) { VoiceProfile.JARVIS_CLASSIC }
        }
        set(value) = prefs.edit().putString("voice_profile", value.name).apply()

    var selectedVoiceName: String?
        get() = prefs.getString("selected_voice_name", null)
        set(value) = prefs.edit().putString("selected_voice_name", value).apply()

    var userApiKey: String
        get() = prefs.getString("user_api_key", "") ?: ""
        set(value) = prefs.edit().putString("user_api_key", value.trim()).apply()

    var isMuted: Boolean
        get() = prefs.getBoolean("is_muted", false)
        set(value) = prefs.edit().putBoolean("is_muted", value).apply()

    var aiModel: String
        get() = prefs.getString("ai_model", "gemini-3.5-flash") ?: "gemini-3.5-flash"
        set(value) = prefs.edit().putString("ai_model", value).apply()

    fun getTasks(): List<TaskItem> {
        val raw = prefs.getString("tasks_json", null) ?: return defaultTasks()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<TaskItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    TaskItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        category = obj.optString("category", "Stark Protocol"),
                        isDone = obj.optBoolean("isDone", false),
                        priority = obj.optString("priority", "High"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            defaultTasks()
        }
    }

    fun saveTasks(tasks: List<TaskItem>) {
        val arr = JSONArray()
        tasks.forEach { task ->
            val obj = JSONObject().apply {
                put("id", task.id)
                put("title", task.title)
                put("category", task.category)
                put("isDone", task.isDone)
                put("priority", task.priority)
                put("timestamp", task.timestamp)
            }
            arr.put(obj)
        }
        prefs.edit().putString("tasks_json", arr.toString()).apply()
    }

    fun getMemories(): List<MemoryItem> {
        val raw = prefs.getString("memories_json", null) ?: return defaultMemories()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<MemoryItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    MemoryItem(
                        id = obj.getString("id"),
                        key = obj.getString("key"),
                        value = obj.getString("value"),
                        category = obj.optString("category", "Personal Directive"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            defaultMemories()
        }
    }

    fun saveMemories(memories: List<MemoryItem>) {
        val arr = JSONArray()
        memories.forEach { mem ->
            val obj = JSONObject().apply {
                put("id", mem.id)
                put("key", mem.key)
                put("value", mem.value)
                put("category", mem.category)
                put("timestamp", mem.timestamp)
            }
            arr.put(obj)
        }
        prefs.edit().putString("memories_json", arr.toString()).apply()
    }

    private fun defaultTasks(): List<TaskItem> = listOf(
        TaskItem(title = "Calibrate Arc Reactor resonance frequency", category = "Power Grid", isDone = true, priority = "High"),
        TaskItem(title = "Sync satellite uplink with orbital defense relay", category = "Defense", isDone = false, priority = "Urgent"),
        TaskItem(title = "Scan for quantum anomalies in local sector", category = "Diagnostics", isDone = false, priority = "Medium"),
        TaskItem(title = "Hindi neural model vocabulary fine-tuning", category = "AI Engine", isDone = true, priority = "High")
    )

    private fun defaultMemories(): List<MemoryItem> = listOf(
        MemoryItem(key = "Owner Designation", value = "Sir / Boss (Tony Stark)", category = "Identity"),
        MemoryItem(key = "Primary Language", value = "Bilingual English & Hindi (हिन्दी)", category = "Linguistics"),
        MemoryItem(key = "Security Clearance", value = "Level 9 Stark Alpha Code", category = "Security"),
        MemoryItem(key = "Core Directive", value = "Protect, assist, and calculate optimal solutions", category = "Protocols")
    )
}
