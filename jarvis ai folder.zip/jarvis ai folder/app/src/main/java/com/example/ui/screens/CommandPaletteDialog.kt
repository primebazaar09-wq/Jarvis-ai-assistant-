package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisViewModel
import com.example.ui.components.StarkHudCard

data class PaletteCommand(
    val title: String,
    val description: String,
    val category: String,
    val actionText: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandPaletteDialog(
    viewModel: JarvisViewModel,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    val allCommands = remember {
        listOf(
            PaletteCommand("Open my camera", "Launch optical sensor interface via Android intent", "Device", "Open my camera"),
            PaletteCommand("Show battery status", "Query Arc Reactor power and battery percentage", "Telemetry", "Show battery status"),
            PaletteCommand("Create a reminder", "Add high-priority task to Stark directive protocols", "Task", "Add a reminder to calibrate quantum defense array"),
            PaletteCommand("Translate to Hindi", "Instant bilingual neural translation into Hindi", "Language", "Translate 'All systems operational, ready for flight' to Hindi"),
            PaletteCommand("Explain Python error", "Debug code and syntax troubleshooting", "Coding", "Explain this Python error: TypeError: 'NoneType' object is not callable"),
            PaletteCommand("Search the web", "Query Stark satellite intelligence network", "Search", "Search the web for latest Mars exploration discoveries"),
            PaletteCommand("Switch to red HUD", "Deploy Mark 3 Hotrod Red and Gold armor aesthetics", "Theme", "Switch to the red HUD theme"),
            PaletteCommand("Switch to Stark Cyan", "Deploy classic Mark 85 holographic cyan HUD", "Theme", "Switch to Stark Cyan theme"),
            PaletteCommand("Voice: Set to F.R.I.D.A.Y.", "Tactical high-speed agile speech profile", "Voice", "voice to friday"),
            PaletteCommand("Voice: Set to Classic JARVIS", "Refined British cadence vocal synthesizer", "Voice", "voice to jarvis"),
            PaletteCommand("Voice: Set to Heavy Baritone", "Deep resonant bass synthesizer", "Voice", "baritone voice"),
            PaletteCommand("Voice: Hindi Desi Voice", "Natural Hindi cadence vocal profile", "Voice", "hindi voice"),
            PaletteCommand("Show JARVIS diagnostics", "System overview, RAM, storage, network status", "Diagnostics", "Show JARVIS system diagnostics"),
            PaletteCommand("Open Wi-Fi Settings", "Launch Android Wi-Fi communication settings", "Device", "wifi"),
            PaletteCommand("Open Bluetooth Settings", "Launch Android Bluetooth relay settings", "Device", "bluetooth")
        )
    }

    val filtered = remember(searchQuery) {
        if (searchQuery.isBlank()) allCommands
        else allCommands.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                    it.description.contains(searchQuery, ignoreCase = true) ||
                    it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    BasicAlertDialog(
        onDismissRequest = onDismiss
    ) {
        StarkHudCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            backgroundColor = MaterialTheme.colorScheme.surface
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = primaryColor, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "COMMAND PALETTE",
                            color = primaryColor,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Filter Stark commands...", fontSize = 12.sp, color = Color.Gray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryColor,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filtered) { cmd ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .border(0.8.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.processUserInput(cmd.actionText)
                                    onDismiss()
                                }
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = cmd.title,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${cmd.category.uppercase()} // ${cmd.description}",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Execute",
                                    tint = primaryColor,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
