package com.example.data.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import com.example.data.model.DeviceTelemetry

class DeviceManager(private val context: Context) {

    fun getDeviceTelemetry(): DeviceTelemetry {
        // Battery info
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 85
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
        val batteryPct = if (scale > 0) ((level / scale.toFloat()) * 100).toInt() else 85

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val chargePlug = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val chargingType = when (chargePlug) {
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Cable"
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Fast Charger"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Magnetic Coil"
            else -> if (isCharging) "Charging" else "Battery Powered"
        }

        // Memory info
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)
        val ramFreeMb = memInfo.availMem / (1024 * 1024)
        val ramUsedMb = (ramTotalMb - ramFreeMb).coerceAtLeast(0)

        // Storage info
        val stat = StatFs(Environment.getDataDirectory().path)
        val freeBytes = stat.availableBlocksLong * stat.blockSizeLong
        val freeGb = freeBytes / (1024 * 1024 * 1024)

        // Connectivity
        val connManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connManager.activeNetwork
        val caps = connManager.getNetworkCapabilities(activeNetwork)
        val networkStatus = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Secure Wi-Fi 6 (Encrypted)"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "5G Ultra Wideband"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "High-Speed Quantum Ethernet"
            else -> "Offline / Sensor Array Only"
        }

        val model = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"

        return DeviceTelemetry(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            chargingType = chargingType,
            ramUsedMb = ramUsedMb,
            ramTotalMb = ramTotalMb,
            storageFreeGb = freeGb,
            networkStatus = networkStatus,
            deviceModel = model,
            arcReactorPowerPercent = (batteryPct + 12).coerceAtMost(100)
        )
    }

    fun vibrateHaptic(durationMs: Long = 40) {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (vibrator?.hasVibrator() == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        }
    }

    fun openAppOrSetting(actionKey: String): IntentLaunchResult {
        return try {
            val intent = when (actionKey.lowercase()) {
                "camera" -> Intent("android.media.action.IMAGE_CAPTURE")
                "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
                "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                "settings" -> Intent(Settings.ACTION_SETTINGS)
                "battery" -> Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
                "maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=current+location"))
                "browser" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com"))
                "youtube" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                else -> null
            }

            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                IntentLaunchResult.Success("Executed command: Launched $actionKey interface.")
            } else {
                IntentLaunchResult.Error("No intent registered for '$actionKey'.")
            }
        } catch (e: Exception) {
            IntentLaunchResult.Error("Cannot open $actionKey: ${e.message}")
        }
    }
}

sealed class IntentLaunchResult {
    data class Success(val message: String) : IntentLaunchResult()
    data class Error(val message: String) : IntentLaunchResult()
}
