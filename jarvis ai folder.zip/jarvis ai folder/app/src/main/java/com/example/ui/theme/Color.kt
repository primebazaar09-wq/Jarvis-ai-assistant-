package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stark Industries - Mark 85 Cyan Palette (Default JARVIS)
val StarkCyan = Color(0xFF00E5FF)
val StarkCyanVariant = Color(0xFF00B0FF)
val StarkCyanDark = Color(0xFF006064)
val StarkGlow = Color(0x6600E5FF)
val StarkBackground = Color(0xFF050811)
val StarkSurface = Color(0xFF0A1221)
val StarkSurfaceVariant = Color(0xFF101D33)
val StarkBorder = Color(0xFF1E3A5F)
val StarkTextPrimary = Color(0xFFE1F5FE)
val StarkTextSecondary = Color(0xFF81D4FA)

// Mark 3 Iron Red & Gold
val Mark3Red = Color(0xFFFF3D00)
val Mark3Gold = Color(0xFFFFD600)
val Mark3Background = Color(0xFF0D0303)
val Mark3Surface = Color(0xFF1C0909)
val Mark3Border = Color(0xFF4E1616)

// Stealth Violet
val StealthViolet = Color(0xFF9D4EDD)
val StealthMagenta = Color(0xFFE040FB)
val StealthBackground = Color(0xFF090412)
val StealthSurface = Color(0xFF160D29)
val StealthBorder = Color(0xFF382361)

// Matrix Emerald
val MatrixGreen = Color(0xFF00E676)
val MatrixGreenVariant = Color(0xFF69F0AE)
val MatrixBackground = Color(0xFF020D06)
val MatrixSurface = Color(0xFF091F11)
val MatrixBorder = Color(0xFF1A4726)

enum class JarvisThemeMode(val displayName: String, val primaryColor: Color, val accentColor: Color) {
    STARK_CYAN("Stark Mark 85", StarkCyan, StarkCyanVariant),
    IRON_RED("Iron Mark 3", Mark3Red, Mark3Gold),
    STEALTH_VIOLET("Stealth Violet", StealthViolet, StealthMagenta),
    MATRIX_EMERALD("Matrix Emerald", MatrixGreen, MatrixGreenVariant)
}
