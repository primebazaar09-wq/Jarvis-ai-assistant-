package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiResult
import com.example.data.ai.JarvisAiEngine
import com.example.data.device.DeviceManager
import com.example.data.model.ChatMessage
import com.example.data.model.DeviceTelemetry
import com.example.data.model.JarvisState
import com.example.data.model.LanguageMode
import com.example.data.model.MemoryItem
import com.example.data.model.MessageSender
import com.example.data.model.TaskItem
import com.example.data.model.VoiceProfile
import com.example.data.storage.PreferencesManager
import com.example.data.voice.VoiceManager
import com.example.ui.theme.JarvisThemeMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class JarvisScreen {
    CORE_REACTOR,
    CHAT_CONSOLE,
    ADVANCED_TOOLS,
    TACTICAL_GLOBE,
    SETTINGS_WAKE
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PreferencesManager(application)
    private val aiEngine = JarvisAiEngine()
    val deviceManager = DeviceManager(application)

    private val _jarvisState = MutableStateFlow(JarvisState.IDLE)
    val jarvisState: StateFlow<JarvisState> = _jarvisState.asStateFlow()

    private val _currentScreen = MutableStateFlow(JarvisScreen.CORE_REACTOR)
    val currentScreen: StateFlow<JarvisScreen> = _currentScreen.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _telemetry = MutableStateFlow(deviceManager.getDeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private val _tasks = MutableStateFlow(prefs.getTasks())
    val tasks: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

    private val _memories = MutableStateFlow(prefs.getMemories())
    val memories: StateFlow<List<MemoryItem>> = _memories.asStateFlow()

    private val _languageMode = MutableStateFlow(prefs.languageMode)
    val languageMode: StateFlow<LanguageMode> = _languageMode.asStateFlow()

    private val _themeMode = MutableStateFlow(prefs.themeMode)
    val themeMode: StateFlow<JarvisThemeMode> = _themeMode.asStateFlow()

    private val _customWakeWord = MutableStateFlow(prefs.customWakeWord)
    val customWakeWord: StateFlow<String> = _customWakeWord.asStateFlow()

    private val _wakeWordEnabled = MutableStateFlow(prefs.wakeWordEnabled)
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled.asStateFlow()

    private val _isMuted = MutableStateFlow(prefs.isMuted)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _speechSpeed = MutableStateFlow(prefs.speechSpeed)
    val speechSpeed: StateFlow<Float> = _speechSpeed.asStateFlow()

    private val _speechPitch = MutableStateFlow(prefs.speechPitch)
    val speechPitch: StateFlow<Float> = _speechPitch.asStateFlow()

    private val _voiceProfile = MutableStateFlow(prefs.voiceProfile)
    val voiceProfile: StateFlow<VoiceProfile> = _voiceProfile.asStateFlow()

    private val _selectedVoiceName = MutableStateFlow(prefs.selectedVoiceName)
    val selectedVoiceName: StateFlow<String?> = _selectedVoiceName.asStateFlow()

    private val _userApiKey = MutableStateFlow(prefs.userApiKey)
    val userApiKey: StateFlow<String> = _userApiKey.asStateFlow()

    private val _selectedModel = MutableStateFlow(prefs.aiModel)
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    fun setUserApiKey(key: String) {
        val clean = key.trim()
        _userApiKey.value = clean
        prefs.userApiKey = clean
        deviceManager.vibrateHaptic(40)
        _systemStatusText.value = if (clean.isNotBlank()) "API KEY SAVED // NEURAL LINK ONLINE" else "API KEY REMOVED // OFFLINE PROTOCOL"
    }

    fun isAiKeyConnected(): Boolean {
        return aiEngine.isApiKeyConfigured(_userApiKey.value)
    }

    private val _systemStatusText = MutableStateFlow("ALL SUBSYSTEMS NOMINAL // QUANTUM CORE ONLINE")
    val systemStatusText: StateFlow<String> = _systemStatusText.asStateFlow()

    // Voice manager
    val voiceManager: VoiceManager = VoiceManager(
        context = application,
        onResult = { recognizedText ->
            processUserInput(recognizedText)
        },
        onError = { err ->
            _systemStatusText.value = "VOICE SENSOR: $err"
            _jarvisState.value = JarvisState.IDLE
        },
        onWakeWordDetected = { triggerPhrase ->
            onWakeWordTriggered(triggerPhrase)
        }
    ).apply {
        customWakeWord = prefs.customWakeWord
        isMuted = prefs.isMuted
        speechSpeed = prefs.speechSpeed
        speechPitch = prefs.speechPitch
        voiceProfile = prefs.voiceProfile
        selectedVoiceName = prefs.selectedVoiceName
        languageMode = prefs.languageMode
    }

    init {
        // Welcome message
        val welcomeGreeting = if (prefs.languageMode == LanguageMode.HINDI) {
            "नमस्ते सर! जार्विस मार्क 85 तैयार है। आदेश दें।"
        } else {
            "At your service, Sir. JARVIS Mark 85 holographic interface initialized. Systems nominal."
        }
        addMessage(ChatMessage(sender = MessageSender.JARVIS, text = welcomeGreeting))

        // Start continuous wake word if enabled
        if (_wakeWordEnabled.value) {
            startWakeWordListening()
        }
    }

    fun setScreen(screen: JarvisScreen) {
        _currentScreen.value = screen
    }

    fun setLanguageMode(mode: LanguageMode) {
        _languageMode.value = mode
        prefs.languageMode = mode
        voiceManager.languageMode = mode
        val msg = if (mode == LanguageMode.HINDI) "भाषा विधा: हिन्दी सक्रिय।" else "Language protocol updated: ${mode.displayName}"
        _systemStatusText.value = msg
    }

    fun setThemeMode(theme: JarvisThemeMode) {
        _themeMode.value = theme
        prefs.themeMode = theme
    }

    fun setCustomWakeWord(newWakeWord: String) {
        if (newWakeWord.isNotBlank()) {
            _customWakeWord.value = newWakeWord.trim()
            prefs.customWakeWord = newWakeWord.trim()
            voiceManager.customWakeWord = newWakeWord.trim()
            _systemStatusText.value = "WAKE WORD UPDATED: '${newWakeWord.trim()}'"
            deviceManager.vibrateHaptic(50)
        }
    }

    fun toggleWakeWord(enabled: Boolean) {
        _wakeWordEnabled.value = enabled
        prefs.wakeWordEnabled = enabled
        if (enabled) {
            startWakeWordListening()
            _systemStatusText.value = "ACOUSTIC SENSORS: CONTINUOUS WAKE WORD ARMED"
        } else {
            stopWakeWordListening()
            _systemStatusText.value = "ACOUSTIC SENSORS: PASSIVE MODE"
        }
    }

    fun toggleMute() {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        prefs.isMuted = newMute
        voiceManager.isMuted = newMute
        if (newMute) {
            voiceManager.stopSpeaking()
        }
    }

    fun setVoiceProfile(profile: VoiceProfile) {
        _voiceProfile.value = profile
        prefs.voiceProfile = profile
        voiceManager.applyVoiceProfile(profile)
        if (profile != VoiceProfile.CUSTOM_SYNTHESIS) {
            _speechPitch.value = profile.defaultPitch
            _speechSpeed.value = profile.defaultSpeed
            prefs.speechPitch = profile.defaultPitch
            prefs.speechSpeed = profile.defaultSpeed
        }
        _systemStatusText.value = "TTS PROFILE: ${profile.displayName.uppercase()}"
        deviceManager.vibrateHaptic(30)
    }

    fun setSpeechPitch(pitch: Float) {
        _speechPitch.value = pitch
        prefs.speechPitch = pitch
        voiceManager.setPitch(pitch)
        _voiceProfile.value = VoiceProfile.CUSTOM_SYNTHESIS
        prefs.voiceProfile = VoiceProfile.CUSTOM_SYNTHESIS
    }

    fun setSpeechSpeed(speed: Float) {
        _speechSpeed.value = speed
        prefs.speechSpeed = speed
        voiceManager.setSpeed(speed)
        _voiceProfile.value = VoiceProfile.CUSTOM_SYNTHESIS
        prefs.voiceProfile = VoiceProfile.CUSTOM_SYNTHESIS
    }

    fun setSelectedVoice(voiceName: String?) {
        _selectedVoiceName.value = voiceName
        prefs.selectedVoiceName = voiceName
        voiceManager.setSelectedVoice(voiceName)
    }

    fun testTtsVoice(sampleText: String? = null) {
        deviceManager.vibrateHaptic(20)
        val text = sampleText ?: if (_languageMode.value == LanguageMode.HINDI) {
            "नमस्ते सर! जार्विस वाक् संश्लेषण प्रणाली पूरी तरह से कैलिब्रेट हो चुकी है।"
        } else {
            "At your service, Sir. Speech synthesis parameters successfully calibrated."
        }
        voiceManager.speak(text)
    }

    fun setSelectedModel(model: String) {
        _selectedModel.value = model
        prefs.aiModel = model
    }

    fun startListeningManual() {
        deviceManager.vibrateHaptic(30)
        _jarvisState.value = JarvisState.LISTENING
        voiceManager.isContinuousWakeWordActive = false
        voiceManager.startListening(isWakeWordMode = false)
    }

    fun stopListeningManual() {
        voiceManager.stopListening()
        _jarvisState.value = JarvisState.IDLE
        if (_wakeWordEnabled.value) {
            startWakeWordListening()
        }
    }

    fun interruptSpeaking() {
        voiceManager.stopSpeaking()
        _jarvisState.value = JarvisState.IDLE
    }

    private fun startWakeWordListening() {
        voiceManager.isContinuousWakeWordActive = true
        voiceManager.startListening(isWakeWordMode = true)
    }

    private fun stopWakeWordListening() {
        voiceManager.isContinuousWakeWordActive = false
        voiceManager.stopListening()
    }

    private fun onWakeWordTriggered(trigger: String) {
        deviceManager.vibrateHaptic(80)
        _jarvisState.value = JarvisState.LISTENING
        val prompt = if (_languageMode.value == LanguageMode.HINDI) "जी सर, आदेश दें।" else "At your service, Sir."
        voiceManager.speak(prompt)
        // Now listen for the actual command
        viewModelScope.launch {
            delay(1200)
            voiceManager.startListening(isWakeWordMode = false)
        }
    }

    fun processUserInput(input: String, attachedBitmap: Bitmap? = null) {
        if (input.isBlank() && attachedBitmap == null) return

        deviceManager.vibrateHaptic(25)
        addMessage(ChatMessage(sender = MessageSender.USER, text = input))
        _jarvisState.value = JarvisState.THINKING
        _systemStatusText.value = "NEURAL PROCESSING // QUERY: '${input.take(24)}...'"

        // Check for local device commands first
        val commandResult = handleLocalDeviceCommand(input)
        if (commandResult != null) {
            viewModelScope.launch {
                delay(400)
                _jarvisState.value = JarvisState.SPEAKING
                addMessage(ChatMessage(sender = MessageSender.JARVIS, text = commandResult))
                voiceManager.speak(commandResult)
                delay(1500)
                _jarvisState.value = JarvisState.IDLE
                if (_wakeWordEnabled.value) startWakeWordListening()
            }
            return
        }

        // Delegate to AI Engine (Gemini / Stark fallback)
        viewModelScope.launch {
            val response = aiEngine.generateResponse(
                prompt = input,
                history = _messages.value,
                languageMode = _languageMode.value,
                bitmap = attachedBitmap,
                selectedModel = _selectedModel.value,
                customApiKey = _userApiKey.value
            )

            when (response) {
                is AiResult.Success -> {
                    _jarvisState.value = JarvisState.SPEAKING
                    _systemStatusText.value = "RESPONSE READY // TRANSMITTING"
                    addMessage(ChatMessage(sender = MessageSender.JARVIS, text = response.text))
                    voiceManager.speak(response.text)
                    delay(800)
                    _jarvisState.value = JarvisState.IDLE
                }
                is AiResult.Error -> {
                    _jarvisState.value = JarvisState.ERROR
                    _systemStatusText.value = "DIAGNOSTIC ALERT // ${response.message.take(30)}"
                    addMessage(ChatMessage(sender = MessageSender.JARVIS, text = response.message))
                    voiceManager.speak("Sir, a communication exception was encountered.")
                    delay(2500)
                    _jarvisState.value = JarvisState.IDLE
                }
            }
            if (_wakeWordEnabled.value) {
                startWakeWordListening()
            }
        }
    }

    private fun handleLocalDeviceCommand(input: String): String? {
        val lower = input.lowercase().trim()

        if (lower.contains("camera") || lower.contains("कैमरा")) {
            val res = deviceManager.openAppOrSetting("camera")
            return if (res is com.example.data.device.IntentLaunchResult.Success) {
                if (_languageMode.value == LanguageMode.HINDI) "कैमरा ऑप्टिक्स सक्रिय किया गया, सर।" else "Camera interface engaged, Sir."
            } else {
                "Unable to access camera sensors directly."
            }
        }

        if (lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("वाईफाई")) {
            deviceManager.openAppOrSetting("wifi")
            return if (_languageMode.value == LanguageMode.HINDI) "वाई-फाई संचार सेटिंग्स खोली जा रही हैं, सर।" else "Accessing Wi-Fi communication array, Sir."
        }

        if (lower.contains("bluetooth") || lower.contains("ब्लूटूथ")) {
            deviceManager.openAppOrSetting("bluetooth")
            return if (_languageMode.value == LanguageMode.HINDI) "ब्लूटूथ रिले सेटिंग्स प्रदर्शित की जा रही हैं।" else "Accessing Bluetooth relay configuration, Sir."
        }

        if (lower.contains("battery") || lower.contains("बैटरी") || lower.contains("चार्ज")) {
            val t = deviceManager.getDeviceTelemetry()
            _telemetry.value = t
            return if (_languageMode.value == LanguageMode.HINDI) {
                "सर, बैटरी स्तर ${t.batteryPercent}% है। आर्क रिएक्टर पावर स्थिर है। पॉवर स्रोत: ${t.chargingType}।"
            } else {
                "Sir, battery telemetry indicates ${t.batteryPercent}% capacity. Power source: ${t.chargingType}. Arc Reactor core stability optimal."
            }
        }

        if (lower.contains("red hud") || lower.contains("mark 3") || lower.contains("लाल थीम")) {
            setThemeMode(JarvisThemeMode.IRON_RED)
            return if (_languageMode.value == LanguageMode.HINDI) "मार्क 3 आयरन रेड थीम सक्रिय की गई, सर।" else "Mark 3 Iron armor aesthetic deployed, Sir."
        }

        if (lower.contains("cyan") || lower.contains("blue") || lower.contains("नीली थीम") || lower.contains("stark theme")) {
            setThemeMode(JarvisThemeMode.STARK_CYAN)
            return if (_languageMode.value == LanguageMode.HINDI) "स्टार्क सियान मार्क 85 इंटरफ़ेस सक्रिय।" else "Mark 85 Stark Cyan HUD engaged, Sir."
        }

        if (lower.contains("stealth") || lower.contains("violet") || lower.contains("बैंगनी")) {
            setThemeMode(JarvisThemeMode.STEALTH_VIOLET)
            return "Stealth Violet telemetry palette deployed, Sir."
        }

        if (lower.contains("matrix") || lower.contains("green") || lower.contains("हरी थीम")) {
            setThemeMode(JarvisThemeMode.MATRIX_EMERALD)
            return "Matrix Emerald protocol engaged, Sir."
        }

        if (lower.contains("voice to friday") || lower.contains("friday voice") || lower.contains("आवाज फ्राइडे")) {
            setVoiceProfile(VoiceProfile.FRIDAY_TACTICAL)
            return if (_languageMode.value == LanguageMode.HINDI) "फ्राइडे टैक्टिकल वॉइस प्रोफ़ाइल सक्रिय की गई।" else "F.R.I.D.A.Y. tactical speech profile engaged, Sir."
        }

        if (lower.contains("voice to jarvis") || lower.contains("classic voice") || lower.contains("जार्विस आवाज")) {
            setVoiceProfile(VoiceProfile.JARVIS_CLASSIC)
            return if (_languageMode.value == LanguageMode.HINDI) "क्लासिक जार्विस वाक् प्रोफ़ाइल सक्रिय।" else "J.A.R.V.I.S. classic British vocal synthesizer restored, Sir."
        }

        if (lower.contains("baritone voice") || lower.contains("deep voice") || lower.contains("गंभीर आवाज")) {
            setVoiceProfile(VoiceProfile.BARITONE_ARMOR)
            return "Heavy Armor resonant baritone synthesizer engaged, Sir."
        }

        if (lower.contains("edith voice") || lower.contains("voice to edith")) {
            setVoiceProfile(VoiceProfile.EDITH_SECURITY)
            return "E.D.I.T.H. defense intelligence vocal profile operational, Sir."
        }

        if (lower.contains("desi voice") || lower.contains("hindi voice") || lower.contains("हिन्दी आवाज")) {
            setVoiceProfile(VoiceProfile.HINDI_AUTHENTIC)
            return "स्वाभाविक हिन्दी भारतीय वाक् प्रोफ़ाइल सक्रिय की गई, सर।"
        }

        if (lower.contains("diagnostics") || lower.contains("जांच") || lower.contains("सिस्टम स्टेटस")) {
            refreshTelemetry()
            return if (_languageMode.value == LanguageMode.HINDI) {
                "सभी प्रणालियां हरी हैं, सर। रैम उपयोग: ${_telemetry.value.ramUsedMb} एमबी, स्टोरेज: ${_telemetry.value.storageFreeGb} जीबी शेष।"
            } else {
                "All primary Stark subsystems operating at peak efficiency. RAM allocation: ${_telemetry.value.ramUsedMb} MB of ${_telemetry.value.ramTotalMb} MB."
            }
        }

        return null
    }

    fun refreshTelemetry() {
        _telemetry.value = deviceManager.getDeviceTelemetry()
    }

    fun addTask(title: String, category: String = "Stark Protocol") {
        val updated = _tasks.value + TaskItem(title = title, category = category)
        _tasks.value = updated
        prefs.saveTasks(updated)
    }

    fun toggleTask(id: String) {
        val updated = _tasks.value.map {
            if (it.id == id) it.copy(isDone = !it.isDone) else it
        }
        _tasks.value = updated
        prefs.saveTasks(updated)
    }

    fun deleteTask(id: String) {
        val updated = _tasks.value.filter { it.id != id }
        _tasks.value = updated
        prefs.saveTasks(updated)
    }

    fun addMemory(key: String, value: String, category: String = "Personal Directive") {
        val updated = _memories.value + MemoryItem(key = key, value = value, category = category)
        _memories.value = updated
        prefs.saveMemories(updated)
    }

    fun deleteMemory(id: String) {
        val updated = _memories.value.filter { it.id != id }
        _memories.value = updated
        prefs.saveMemories(updated)
    }

    fun clearHistory() {
        _messages.value = emptyList()
        addMessage(ChatMessage(sender = MessageSender.SYSTEM, text = "Conversation log purged."))
    }

    private fun addMessage(msg: ChatMessage) {
        _messages.value = _messages.value + msg
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
