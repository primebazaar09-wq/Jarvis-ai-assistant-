package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

fun getJarvisColorScheme(themeMode: JarvisThemeMode) = when (themeMode) {
    JarvisThemeMode.STARK_CYAN -> darkColorScheme(
        primary = StarkCyan,
        onPrimary = Color.Black,
        primaryContainer = StarkSurfaceVariant,
        onPrimaryContainer = StarkCyan,
        secondary = StarkCyanVariant,
        onSecondary = Color.Black,
        background = StarkBackground,
        onBackground = StarkTextPrimary,
        surface = StarkSurface,
        onSurface = StarkTextPrimary,
        surfaceVariant = StarkSurfaceVariant,
        onSurfaceVariant = StarkTextSecondary,
        outline = StarkBorder
    )
    JarvisThemeMode.IRON_RED -> darkColorScheme(
        primary = Mark3Red,
        onPrimary = Color.White,
        primaryContainer = Mark3Surface,
        onPrimaryContainer = Mark3Gold,
        secondary = Mark3Gold,
        onSecondary = Color.Black,
        background = Mark3Background,
        onBackground = Color(0xFFFFEBEE),
        surface = Mark3Surface,
        onSurface = Color(0xFFFFCDD2),
        surfaceVariant = Color(0xFF2A1010),
        onSurfaceVariant = Mark3Gold,
        outline = Mark3Border
    )
    JarvisThemeMode.STEALTH_VIOLET -> darkColorScheme(
        primary = StealthViolet,
        onPrimary = Color.White,
        primaryContainer = StealthSurface,
        onPrimaryContainer = StealthMagenta,
        secondary = StealthMagenta,
        onSecondary = Color.Black,
        background = StealthBackground,
        onBackground = Color(0xFFF3E5F5),
        surface = StealthSurface,
        onSurface = Color(0xFFE1BEE7),
        surfaceVariant = Color(0xFF23163E),
        onSurfaceVariant = StealthMagenta,
        outline = StealthBorder
    )
    JarvisThemeMode.MATRIX_EMERALD -> darkColorScheme(
        primary = MatrixGreen,
        onPrimary = Color.Black,
        primaryContainer = MatrixSurface,
        onPrimaryContainer = MatrixGreenVariant,
        secondary = MatrixGreenVariant,
        onSecondary = Color.Black,
        background = MatrixBackground,
        onBackground = Color(0xFFE8F5E9),
        surface = MatrixSurface,
        onSurface = Color(0xFFC8E6C9),
        surfaceVariant = Color(0xFF102E19),
        onSurfaceVariant = MatrixGreenVariant,
        outline = MatrixBorder
    )
}

@Composable
fun JarvisTheme(
    themeMode: JarvisThemeMode = JarvisThemeMode.STARK_CYAN,
    content: @Composable () -> Unit
) {
    val colorScheme = getJarvisColorScheme(themeMode)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
