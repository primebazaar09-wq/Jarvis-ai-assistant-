package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun HudScanningSweepOverlay(
    modifier: Modifier = Modifier,
    scanDurationMillis: Int = 5000,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    val transition = rememberInfiniteTransition(label = "HudScanningSweep")

    // Progress moves from -0.1f (above screen) to 1.1f (below screen)
    val sweepProgress by transition.animateFloat(
        initialValue = -0.1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = scanDurationMillis, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepProgress"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val sweepY = size.height * sweepProgress
        val beamHeight = 60.dp.toPx()

        // Only draw when on screen
        if (sweepY >= -beamHeight && sweepY <= size.height + beamHeight) {
            // 1. Trailing holographic scan glow gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        accentColor.copy(alpha = 0.03f),
                        accentColor.copy(alpha = 0.12f),
                        accentColor.copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    startY = sweepY - beamHeight,
                    endY = sweepY + 4.dp.toPx()
                ),
                topLeft = Offset(0f, sweepY - beamHeight),
                size = Size(size.width, beamHeight + 4.dp.toPx())
            )

            // 2. Crisp laser line across width
            drawLine(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        accentColor.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.85f),
                        accentColor.copy(alpha = 0.5f),
                        Color.Transparent
                    )
                ),
                start = Offset(0f, sweepY),
                end = Offset(size.width, sweepY),
                strokeWidth = 1.5.dp.toPx()
            )

            // 3. Digital telemetry tick marks on the edges of the scanline
            val tickWidth = 14.dp.toPx()
            // Left tick
            drawLine(
                color = accentColor,
                start = Offset(0f, sweepY - 4.dp.toPx()),
                end = Offset(tickWidth, sweepY - 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            // Right tick
            drawLine(
                color = accentColor,
                start = Offset(size.width - tickWidth, sweepY - 4.dp.toPx()),
                end = Offset(size.width, sweepY - 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}
