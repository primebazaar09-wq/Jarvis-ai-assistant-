package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import com.example.ui.JarvisScreen
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JarvisState
import com.example.data.model.LanguageMode
import com.example.ui.JarvisViewModel
import com.example.ui.components.ArcReactorView
import com.example.ui.components.HudScanningSweepOverlay
import com.example.ui.components.StarkHudCard
import com.example.ui.components.StarkTelemetryChip

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CoreReactorScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.jarvisState.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val languageMode by viewModel.languageMode.collectAsState()
    val customWakeWord by viewModel.customWakeWord.collectAsState()
    val wakeWordEnabled by viewModel.wakeWordEnabled.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val systemStatus by viewModel.systemStatusText.collectAsState()

    val rmsLevel by viewModel.voiceManager.rmsLevel.collectAsState()
    val liveTranscript by viewModel.voiceManager.liveTranscript.collectAsState()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val primaryColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        // --- 1. Top HUD Status Header ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S. // MARK LXXXV",
                    color = primaryColor,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "PWR: ${telemetry.arcReactorPowerPercent}% // BATT: ${telemetry.batteryPercent}% (${telemetry.chargingType})",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language quick toggle chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, primaryColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .clickable {
                            val nextMode = when (languageMode) {
                                LanguageMode.AUTO -> LanguageMode.HINDI
                                LanguageMode.HINDI -> LanguageMode.ENGLISH
                                LanguageMode.ENGLISH -> LanguageMode.AUTO
                            }
                            viewModel.setLanguageMode(nextMode)
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("lang_toggle_chip")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Language",
                            tint = primaryColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = when (languageMode) {
                                LanguageMode.AUTO -> "AUTO"
                                LanguageMode.HINDI -> "हिन्दी"
                                LanguageMode.ENGLISH -> "EN"
                            },
                            color = primaryColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Mute toggle
                IconButton(
                    onClick = { viewModel.toggleMute() },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("mute_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = if (isMuted) "Unmute" else "Mute",
                        tint = if (isMuted) Color(0xFFFF5252) else primaryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 2. Central Holographic Arc Reactor ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            ArcReactorView(
                state = state,
                audioRms = rmsLevel,
                size = 230.dp,
                onClick = {
                    if (state == JarvisState.LISTENING) {
                        viewModel.stopListeningManual()
                    } else if (state == JarvisState.SPEAKING) {
                        viewModel.interruptSpeaking()
                    } else {
                        viewModel.startListeningManual()
                    }
                }
            )
        }

        // --- 3. Dynamic State & Wake Word HUD Badge ---
        val stateText = when (state) {
            JarvisState.IDLE -> "STATUS: IDLE // LISTENING FOR WAKE WORD"
            JarvisState.LISTENING -> "STATUS: LISTENING // ACOUSTIC MESH ACTIVE"
            JarvisState.THINKING -> "STATUS: THINKING // QUANTUM NEURAL COMPUTE"
            JarvisState.SPEAKING -> "STATUS: VOCALIZING // SPEECH SYNTHESIS"
            JarvisState.ERROR -> "STATUS: ALERT // EXCEPTION LOGGED"
        }

        StarkHudCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stateText,
                    color = when (state) {
                        JarvisState.ERROR -> Color(0xFFFF1744)
                        JarvisState.LISTENING -> primaryColor
                        JarvisState.THINKING -> Color(0xFFFFD600)
                        JarvisState.SPEAKING -> Color(0xFF76FFFF)
                        JarvisState.IDLE -> primaryColor.copy(alpha = 0.85f)
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WAKE WORD: ",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "'$customWakeWord'",
                        color = primaryColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (wakeWordEnabled) " [ARMED]" else " [STANDBY]",
                        color = if (wakeWordEnabled) Color(0xFF00E676) else Color.Gray,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Live Transcription stream if any
                AnimatedVisibility(
                    visible = liveTranscript.isNotBlank() && state == JarvisState.LISTENING,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Text(
                        text = "“$liveTranscript”",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 3.5. Neural Uplink / API Key Status Card ---
        val isKeyConnected = viewModel.isAiKeyConnected()
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(
                    if (isKeyConnected) primaryColor.copy(alpha = 0.12f)
                    else Color(0xFFFF9100).copy(alpha = 0.15f)
                )
                .border(
                    1.dp,
                    if (isKeyConnected) primaryColor.copy(alpha = 0.5f)
                    else Color(0xFFFF9100),
                    RoundedCornerShape(8.dp)
                )
                .clickable {
                    viewModel.setScreen(JarvisScreen.SETTINGS_WAKE)
                }
                .padding(horizontal = 12.dp, vertical = 9.dp)
                .testTag("neural_uplink_key_status")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "API Key",
                        tint = if (isKeyConnected) primaryColor else Color(0xFFFF9100),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isKeyConnected) "NEURAL UPLINK: GEMINI AI ONLINE" else "NEURAL UPLINK: API KEY NEEDED",
                            color = if (isKeyConnected) primaryColor else Color(0xFFFF9100),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isKeyConnected) "Tap to change model or speech parameters" else "Tap here to paste your Gemini API Key directly",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Configure Key",
                    tint = if (isKeyConnected) primaryColor else Color(0xFFFF9100),
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 4. Subsystem Telemetry Tickers ---
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StarkTelemetryChip(label = "NET", value = telemetry.networkStatus.take(16))
            StarkTelemetryChip(label = "RAM", value = "${telemetry.ramUsedMb}/${telemetry.ramTotalMb}MB")
            StarkTelemetryChip(label = "STORAGE", value = "${telemetry.storageFreeGb}GB FREE")
            StarkTelemetryChip(
                label = "CORE",
                value = if (viewModel.deviceManager.getDeviceTelemetry().isCharging) "CHARGING" else "NOMINAL"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- 5. Quick Stark Protocols & Commands ---
        Text(
            text = "DIRECTIVE PROTOCOLS",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(4.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "Run Diagnostics" to "Show JARVIS system diagnostics",
                "Open Camera" to "Open my camera",
                "Voice: FRIDAY" to "voice to friday",
                "Voice: JARVIS" to "voice to jarvis",
                "Battery Status" to "Show battery status",
                "Translate to Hindi" to "Translate 'Greetings Sir, systems are ready' to Hindi",
                "Mark 3 Red HUD" to "Switch to the red HUD theme",
                "Stark Cyan HUD" to "Switch to Stark Cyan theme"
            ).forEach { (label, command) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, primaryColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .clickable { viewModel.processUserInput(command) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("quick_command_${label.replace(" ", "_")}")
                ) {
                    Text(
                        text = label,
                        color = primaryColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- 6. Command Input & Voice Bar ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("command_input_field"),
                placeholder = {
                    Text(
                        text = if (languageMode == LanguageMode.HINDI) "आदेश दर्ज करें या 'जार्विस' कहें..." else "Enter command or say '${customWakeWord}'...",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                },
                maxLines = 2,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = primaryColor,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = primaryColor
                ),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Push to talk / Mic button
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (state == JarvisState.LISTENING) Color(0xFFFF1744) else primaryColor
                    )
                    .clickable {
                        if (state == JarvisState.LISTENING) {
                            viewModel.stopListeningManual()
                        } else {
                            viewModel.startListeningManual()
                        }
                    }
                    .testTag("push_to_talk_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (state == JarvisState.LISTENING) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = Color.Black,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Interrupt speaking button (if speaking) or Send button
            if (isSpeaking || state == JarvisState.SPEAKING) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF9100))
                        .clickable { viewModel.interruptSpeaking() }
                        .testTag("interrupt_speech_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Speech",
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            if (textInput.isNotBlank()) primaryColor else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable {
                            if (textInput.isNotBlank()) {
                                viewModel.processUserInput(textInput)
                                textInput = ""
                            }
                        }
                        .testTag("send_command_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send Command",
                        tint = if (textInput.isNotBlank()) Color.Black else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // System bottom notification
        Text(
            text = systemStatus,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center
        )
        }

        // Canvas-based periodic Stark HUD scanning sweep
        HudScanningSweepOverlay(
            modifier = Modifier.fillMaxSize(),
            scanDurationMillis = 4500,
            accentColor = primaryColor
        )
    }
}
