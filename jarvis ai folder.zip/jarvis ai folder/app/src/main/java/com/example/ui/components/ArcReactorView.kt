package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.JarvisState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorView(
    state: JarvisState,
    audioRms: Float,
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorTransition")

    // Slow continuous outer rotation
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outerRot"
    )

    // Inner counter-rotation
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "innerRot"
    )

    // Core pulsing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    JarvisState.THINKING -> 600
                    JarvisState.LISTENING -> 800
                    JarvisState.SPEAKING -> 500
                    JarvisState.ERROR -> 300
                    JarvisState.IDLE -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Scanning radar sweep angle
    val scanAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scan"
    )

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val stateColor = when (state) {
        JarvisState.ERROR -> Color(0xFFFF1744)
        JarvisState.LISTENING -> Color(0xFF00E5FF)
        JarvisState.THINKING -> Color(0xFFFFD600)
        JarvisState.SPEAKING -> Color(0xFF76FFFF)
        JarvisState.IDLE -> primaryColor
    }

    Box(
        modifier = modifier
            .size(size)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f - 12.dp.toPx()

            // 1. Ambient Glow Radial Gradient
            val glowRadius = radius * (pulseScale + (audioRms * 0.25f))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        stateColor.copy(alpha = if (state == JarvisState.LISTENING) 0.45f else 0.25f),
                        stateColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = glowRadius * 1.3f
                ),
                radius = glowRadius * 1.3f,
                center = center
            )

            // 2. Sound-Reactive Frequency Waveform Bars (around perimeter)
            val totalBars = 36
            val barBaseRadius = radius * 0.98f
            for (i in 0 until totalBars) {
                val angleRad = (i * (360f / totalBars) + outerRotation) * (PI / 180f).toFloat()
                val waveFactor = when (state) {
                    JarvisState.LISTENING, JarvisState.SPEAKING -> {
                        val phase = sin(i * 0.5f + outerRotation * 0.1f)
                        (audioRms * 28.dp.toPx() * (0.4f + 0.6f * phase)).coerceAtLeast(4.dp.toPx())
                    }
                    JarvisState.THINKING -> (sin(i * 0.8f + scanAngle * 0.05f) * 8.dp.toPx()).coerceAtLeast(3.dp.toPx())
                    else -> 3.dp.toPx()
                }

                val startX = center.x + cos(angleRad) * barBaseRadius
                val startY = center.y + sin(angleRad) * barBaseRadius
                val endX = center.x + cos(angleRad) * (barBaseRadius + waveFactor)
                val endY = center.y + sin(angleRad) * (barBaseRadius + waveFactor)

                drawLine(
                    color = stateColor.copy(alpha = 0.65f),
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = 2.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 3. Outermost Segmented Ring (Rotating with dashed arc segments)
            rotate(outerRotation, center) {
                drawCircle(
                    color = stateColor.copy(alpha = 0.7f),
                    radius = radius * 0.92f,
                    center = center,
                    style = Stroke(
                        width = 3.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(45f, 25f, 15f, 25f), 0f)
                    )
                )

                // 8 Tick marks on outer rim
                for (j in 0 until 8) {
                    val tickAngle = j * 45f * (PI / 180f).toFloat()
                    val tStartX = center.x + cos(tickAngle) * (radius * 0.88f)
                    val tStartY = center.y + sin(tickAngle) * (radius * 0.88f)
                    val tEndX = center.x + cos(tickAngle) * (radius * 0.96f)
                    val tEndY = center.y + sin(tickAngle) * (radius * 0.96f)
                    drawLine(
                        color = secondaryColor.copy(alpha = 0.9f),
                        start = Offset(tStartX, tStartY),
                        end = Offset(tEndX, tEndY),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // 4. Middle Arc Rotor with 10 power blocks
            rotate(innerRotation, center) {
                val blockRadius = radius * 0.74f
                drawCircle(
                    color = stateColor.copy(alpha = 0.4f),
                    radius = blockRadius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                val blockCount = 10
                for (k in 0 until blockCount) {
                    val bAngle = k * (360f / blockCount) * (PI / 180f).toFloat()
                    val bx = center.x + cos(bAngle) * blockRadius
                    val by = center.y + sin(bAngle) * blockRadius
                    drawCircle(
                        color = stateColor,
                        radius = 3.5.dp.toPx(),
                        center = Offset(bx, by)
                    )
                }
            }

            // 5. Radar Scanning Sweep (Active in Thinking / Listening)
            if (state == JarvisState.THINKING || state == JarvisState.LISTENING) {
                rotate(scanAngle, center) {
                    val sweepRadius = radius * 0.70f
                    val sweepPath = Path().apply {
                        moveTo(center.x, center.y)
                        val angle1 = 0f
                        val angle2 = 45f * (PI / 180f).toFloat()
                        lineTo(center.x + sweepRadius, center.y)
                        lineTo(center.x + cos(angle2) * sweepRadius, center.y + sin(angle2) * sweepRadius)
                        close()
                    }
                    drawPath(
                        path = sweepPath,
                        brush = Brush.radialGradient(
                            colors = listOf(stateColor.copy(alpha = 0.35f), Color.Transparent),
                            center = center,
                            radius = sweepRadius
                        )
                    )
                }
            }

            // 6. Inner Core Energy Chamber
            val coreRadius = radius * 0.44f * pulseScale
            drawCircle(
                color = stateColor.copy(alpha = 0.18f),
                radius = coreRadius,
                center = center
            )
            drawCircle(
                color = stateColor,
                radius = coreRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // 7. Arc Reactor Central Stark Triangle Emblem
            rotate(outerRotation * 0.5f, center) {
                val triRadius = coreRadius * 0.65f
                val triPath = Path().apply {
                    val p1 = Offset(center.x, center.y - triRadius)
                    val p2 = Offset(center.x + cos(30f * PI.toFloat() / 180f) * triRadius, center.y + sin(30f * PI.toFloat() / 180f) * triRadius)
                    val p3 = Offset(center.x - cos(30f * PI.toFloat() / 180f) * triRadius, center.y + sin(30f * PI.toFloat() / 180f) * triRadius)
                    moveTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    close()
                }
                drawPath(
                    path = triPath,
                    color = stateColor.copy(alpha = 0.3f)
                )
                drawPath(
                    path = triPath,
                    color = stateColor,
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Central glowing point
                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx() * pulseScale,
                    center = center
                )
            }
        }
    }
}
