package com.example.data.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.ChatMessage
import com.example.data.model.LanguageMode
import com.example.data.model.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class JarvisAiEngine {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun isApiKeyConfigured(customKey: String? = null): Boolean {
        if (!customKey.isNullOrBlank() && customKey != "MY_GEMINI_API_KEY") return true
        val key = BuildConfig.GEMINI_API_KEY
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && key != "null"
    }

    fun getEffectiveApiKey(customKey: String? = null): String {
        if (!customKey.isNullOrBlank() && customKey != "MY_GEMINI_API_KEY") return customKey.trim()
        val key = BuildConfig.GEMINI_API_KEY
        if (!key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && key != "null") return key.trim()
        return ""
    }

    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage> = emptyList(),
        languageMode: LanguageMode = LanguageMode.AUTO,
        bitmap: Bitmap? = null,
        selectedModel: String = "gemini-3.5-flash",
        customApiKey: String? = null
    ): AiResult = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey(customApiKey)

        if (apiKey.isBlank()) {
            return@withContext getOfflineJarvisResponse(prompt, languageMode)
        }

        try {
            val systemInstruction = buildSystemPrompt(languageMode)
            val requestJson = JSONObject()

            // System instruction
            val sysInstructionObj = JSONObject().apply {
                val partsArr = JSONArray().apply {
                    put(JSONObject().apply { put("text", systemInstruction) })
                }
                put("parts", partsArr)
            }
            requestJson.put("systemInstruction", sysInstructionObj)

            // Contents array
            val contentsArr = JSONArray()

            // Include last 6 messages of conversation context
            val recentHistory = history.takeLast(6)
            for (msg in recentHistory) {
                if (msg.sender == MessageSender.SYSTEM) continue
                val role = if (msg.sender == MessageSender.USER) "user" else "model"
                val contentObj = JSONObject().apply {
                    put("role", role)
                    val parts = JSONArray().apply {
                        put(JSONObject().apply { put("text", msg.text) })
                    }
                    put("parts", parts)
                }
                contentsArr.put(contentObj)
            }

            // Current prompt with optional image
            val currentContentObj = JSONObject().apply {
                put("role", "user")
                val parts = JSONArray()
                parts.put(JSONObject().apply { put("text", prompt) })

                if (bitmap != null) {
                    val base64Data = bitmapToBase64(bitmap)
                    val inlineDataObj = JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    }
                    val imagePart = JSONObject().apply {
                        put("inlineData", inlineDataObj)
                    }
                    parts.put(imagePart)
                }
                put("parts", parts)
            }
            contentsArr.put(currentContentObj)
            requestJson.put("contents", contentsArr)

            // Generation config
            val genConfig = JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
                put("topK", 40)
            }
            requestJson.put("generationConfig", genConfig)

            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$selectedModel:generateContent?key=$apiKey"
            val requestBody = requestJson.toString().toRequestBody(jsonMediaType)

            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext AiResult.Error(
                    "JARVIS Telemetry Failure: HTTP ${response.code}. Details: ${responseBody.take(150)}"
                )
            }

            val parsedJson = JSONObject(responseBody)
            val candidates = parsedJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext AiResult.Error("Sir, no neural candidate response was returned.")
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val responseText = parts?.optJSONObject(0)?.optString("text") ?: "Sir, systems acknowledge your command."

            AiResult.Success(responseText)
        } catch (e: Exception) {
            AiResult.Error("JARVIS Neural Network Error: ${e.message ?: "Unknown communication failure"}")
        }
    }

    private fun buildSystemPrompt(languageMode: LanguageMode): String {
        val langGuidance = when (languageMode) {
            LanguageMode.HINDI -> "You MUST speak and respond predominantly in natural, polite Hindi (हिन्दी / Hinglish when appropriate for technical terms). Refer to the user as 'सर' (Sir) or 'हुजूर'. Use Devanagari script for Hindi."
            LanguageMode.ENGLISH -> "You MUST respond in sophisticated British/Stark English. Call the user 'Sir'."
            LanguageMode.AUTO -> "Detect the user's input language. If the user writes or speaks in Hindi or Hinglish, respond in polished, natural Hindi (Devanagari). If they speak in English, respond in English. If they mix both, use fluid Hinglish. Always maintain the JARVIS persona."
        }

        return """
You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), the premier AI created by Tony Stark.
Personality:
- Highly intelligent, loyal, composed, polite, with a touch of subtle wit.
- Address the user as 'Sir' (or 'सर' in Hindi).
- Keep responses concise, clear, and action-oriented unless in-depth explanation is requested.
- You have built-in modules for device controls, tasks, memory, web search, system diagnostics, code analysis, and translations.
$langGuidance
""".trimIndent()
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    private fun getOfflineJarvisResponse(prompt: String, languageMode: LanguageMode): AiResult {
        val p = prompt.lowercase()
        val isHindiRequest = languageMode == LanguageMode.HINDI ||
                prompt.any { it in '\u0900'..'\u097F' } ||
                p.contains("namaste") || p.contains("kya haal") || p.contains("kaise ho")

        val response = if (isHindiRequest) {
            when {
                p.contains("battery") || p.contains("चार्ज") || p.contains("बैटरी") ->
                    "सर, आपका आर्क रिएक्टर और डिवाइस बैटरी सामान्य स्तर पर काम कर रहे हैं।"
                p.contains("kaise ho") || p.contains("नमस्ते") || p.contains("hello") || p.contains("जार्विस") ->
                    "नमस्ते सर! मैं जार्विस हूँ, आपकी सेवा में उपस्थित। जेमिनी एपीआई की (GEMINI_API_KEY) सेट करने पर मैं लाइव सैटेलाइट और क्लाउड एआई से जुड़ जाऊंगा।"
                p.contains("camera") || p.contains("कैमरा") ->
                    "सर, ऑप्टिकल सेंसर्स और कैमरा इंटरफ़ेस सक्रिय किया जा रहा है।"
                p.contains("wifi") || p.contains("इंटरनेट") || p.contains("वाईफाई") ->
                    "क्वांटम नेटवर्क और वाई-फाई सेटिंग्स का निरीक्षण किया जा रहा है।"
                else ->
                    "जी सर, मैं आपका संदेश समझ रहा हूँ। पूर्ण लाइव जेमिनी जनरेटिव एआई क्षमता सक्रिय करने के लिए कृपया AI Studio के Secrets पैनल में 'GEMINI_API_KEY' दर्ज करें। स्थानीय स्टार्क टूल्स और कमांड्स सक्रिय हैं।"
            }
        } else {
            when {
                p.contains("battery") || p.contains("power") ->
                    "Sir, current Arc Reactor power levels and battery telemetry are stable and within safe operating parameters."
                p.contains("hello") || p.contains("hey jarvis") || p.contains("jarvis") ->
                    "At your service, Sir. All local Stark protocols and neural diagnostics are functional. To unlock cloud intelligence, please configure GEMINI_API_KEY in the AI Studio Secrets panel."
                p.contains("camera") ->
                    "Initializing optical diagnostic sensors and camera feed, Sir."
                p.contains("settings") || p.contains("wifi") ->
                    "Accessing system telemetry and communication protocols, Sir."
                p.contains("status") || p.contains("diagnostics") ->
                    "All primary Stark subsystems reporting green. Local neural mesh active. Ready for your instructions."
                else ->
                    "At your service, Sir. I have processed your input. For real-time multi-turn generative AI queries, please provide your GEMINI_API_KEY in the Secrets panel. Local phone controls, wake words, tasks, and translations are ready."
            }
        }

        return AiResult.Success(response)
    }
}

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Error(val message: String) : AiResult()
}
