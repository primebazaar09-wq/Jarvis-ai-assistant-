package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HolographicGlobeView(
    modifier: Modifier = Modifier,
    enableAutoRotate: Boolean = true
) {
    var rotationY by remember { mutableFloatStateOf(0f) }
    var rotationX by remember { mutableFloatStateOf(20f) }
    var zoomScale by remember { mutableFloatStateOf(1.0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "GlobeAutoRotate")
    val autoRot by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "globeSpin"
    )

    val currentRotationY = rotationY + if (enableAutoRotate) autoRot else 0f
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    rotationY += pan.x * 0.4f
                    rotationX = (rotationX - pan.y * 0.4f).coerceIn(-75f, 75f)
                    zoomScale = (zoomScale * zoom).coerceIn(0.6f, 2.2f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2.3f) * zoomScale

            val radX = (rotationX * PI / 180f).toFloat()
            val radY = (currentRotationY * PI / 180f).toFloat()

            // 3D Point projection helper
            fun project(latDeg: Float, lonDeg: Float): Triple<Float, Float, Float> {
                val phi = (latDeg * PI / 180f).toFloat()
                val theta = (lonDeg * PI / 180f).toFloat()

                // Sphere coordinates (Radius = 1)
                val x0 = cos(phi) * sin(theta)
                val y0 = -sin(phi)
                val z0 = cos(phi) * cos(theta)

                // Rotate around Y axis (Yaw)
                val x1 = x0 * cos(radY) + z0 * sin(radY)
                val y1 = y0
                val z1 = -x0 * sin(radY) + z0 * cos(radY)

                // Rotate around X axis (Pitch)
                val x2 = x1
                val y2 = y1 * cos(radX) - z1 * sin(radX)
                val z2 = y1 * sin(radX) + z1 * cos(radX)

                val screenX = center.x + x2 * baseRadius
                val screenY = center.y + y2 * baseRadius
                return Triple(screenX, screenY, z2)
            }

            // Draw outer sphere boundary
            drawCircle(
                color = primaryColor.copy(alpha = 0.25f),
                radius = baseRadius,
                center = center,
                style = Stroke(width = 1.5f)
            )

            // Draw latitude parallels (-60 to +60 in steps of 30)
            val latSteps = listOf(-60f, -30f, 0f, 30f, 60f)
            for (lat in latSteps) {
                val pathFront = Path()
                val pathBack = Path()
                var firstFront = true
                var firstBack = true

                for (lon in 0..360 step 8) {
                    val (px, py, pz) = project(lat, lon.toFloat())
                    if (pz >= 0) { // Front hemisphere
                        if (firstFront) {
                            pathFront.moveTo(px, py)
                            firstFront = false
                        } else {
                            pathFront.lineTo(px, py)
                        }
                    } else { // Back hemisphere
                        if (firstBack) {
                            pathBack.moveTo(px, py)
                            firstBack = false
                        } else {
                            pathBack.lineTo(px, py)
                        }
                    }
                }

                // Draw back facing (faint)
                drawPath(
                    path = pathBack,
                    color = primaryColor.copy(alpha = 0.12f),
                    style = Stroke(width = 1f)
                )
                // Draw front facing (bright, thick if equator)
                drawPath(
                    path = pathFront,
                    color = if (lat == 0f) secondaryColor.copy(alpha = 0.85f) else primaryColor.copy(alpha = 0.5f),
                    style = Stroke(width = if (lat == 0f) 2f else 1.2f)
                )
            }

            // Draw longitude meridians (0 to 330 in steps of 30)
            for (lon in 0 until 360 step 30) {
                val pathFront = Path()
                val pathBack = Path()
                var firstFront = true
                var firstBack = true

                for (lat in -90..90 step 8) {
                    val (px, py, pz) = project(lat.toFloat(), lon.toFloat())
                    if (pz >= 0) {
                        if (firstFront) {
                            pathFront.moveTo(px, py)
                            firstFront = false
                        } else {
                            pathFront.lineTo(px, py)
                        }
                    } else {
                        if (firstBack) {
                            pathBack.moveTo(px, py)
                            firstBack = false
                        } else {
                            pathBack.lineTo(px, py)
                        }
                    }
                }

                drawPath(
                    path = pathBack,
                    color = primaryColor.copy(alpha = 0.10f),
                    style = Stroke(width = 1f)
                )
                drawPath(
                    path = pathFront,
                    color = primaryColor.copy(alpha = 0.45f),
                    style = Stroke(width = 1.2f)
                )
            }

            // Tactical Stark Nodes (New York, Mumbai/New Delhi, Tokyo, London, Stark Satellite)
            val tacticalNodes = listOf(
                Pair(40.71f, -74.00f) to "Stark Tower (NYC)",
                Pair(28.61f, 77.20f) to "New Delhi Node",
                Pair(19.07f, 72.87f) to "Mumbai Satellite",
                Pair(51.50f, -0.12f) to "London Defense",
                Pair(35.67f, 139.65f) to "Tokyo Array"
            )

            for ((coord, label) in tacticalNodes) {
                val (px, py, pz) = project(coord.first, coord.second)
                if (pz > 0) { // Only render front nodes
                    val nodeAlpha = (0.3f + 0.7f * pz).coerceIn(0f, 1f)
                    drawCircle(
                        color = Color.White.copy(alpha = nodeAlpha),
                        radius = 4f * zoomScale,
                        center = Offset(px, py)
                    )
                    drawCircle(
                        color = secondaryColor.copy(alpha = nodeAlpha * 0.7f),
                        radius = 8f * zoomScale,
                        center = Offset(px, py),
                        style = Stroke(width = 1.5f)
                    )
                }
            }

            // Orbital Ring (Stark Orbital Defense Net)
            val orbitRadius = baseRadius * 1.25f
            val orbitPath = Path()
            var firstOrbit = true
            for (deg in 0..360 step 6) {
                val rad = (deg * PI / 180f).toFloat()
                val ox = cos(rad) * orbitRadius
                val oy = sin(rad) * 0.35f * orbitRadius
                // Rotate around center
                val scrX = center.x + ox * cos(radX * 0.5f)
                val scrY = center.y + oy + ox * sin(radX * 0.5f)
                if (firstOrbit) {
                    orbitPath.moveTo(scrX, scrY)
                    firstOrbit = false
                } else {
                    orbitPath.lineTo(scrX, scrY)
                }
            }
            drawPath(
                path = orbitPath,
                color = secondaryColor.copy(alpha = 0.4f),
                style = Stroke(width = 1.5f)
            )
        }
    }
}
