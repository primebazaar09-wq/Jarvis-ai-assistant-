package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisViewModel
import com.example.ui.components.HolographicGlobeView
import com.example.ui.components.StarkHudCard
import com.example.ui.components.StarkTelemetryChip

@Composable
fun GlobeTacticalScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 3D Holographic Globe
        HolographicGlobeView(
            modifier = Modifier.fillMaxSize(),
            enableAutoRotate = true
        )

        // Top Overlay HUD
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
                .align(Alignment.TopCenter)
        ) {
            Text(
                text = "STARK PLANETARY DEFENSE // ORBITAL ARRAY",
                color = primaryColor,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "DRAG TO ROTATE GLOBE // PINCH TO ZOOM TELEMETRY",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StarkTelemetryChip(label = "GRID", value = "SYNCED")
                StarkTelemetryChip(label = "NODES", value = "5 ACTIVE")
                StarkTelemetryChip(label = "RELAY", value = "GEOSYNC")
            }
        }

        // Bottom Overlay HUD
        StarkHudCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
                .align(Alignment.BottomCenter),
            backgroundColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f)
        ) {
            Column {
                Text(
                    text = "TARGET COORDINATES // SATELLITE TELEMETRY",
                    color = primaryColor,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "STARK TOWER (NYC): 40.71° N, 74.00° W // DEFENSE STATUS: NOMINAL\nNEW DELHI NODE: 28.61° N, 77.20° E // QUANTUM LINK ACTIVE\nMUMBAI SATELLITE: 19.07° N, 72.87° E // TELEMETRY VERIFIED",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 14.sp
                )
            }
        }
    }
}
