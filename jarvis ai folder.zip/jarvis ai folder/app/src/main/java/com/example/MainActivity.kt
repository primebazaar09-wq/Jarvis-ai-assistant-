package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.JarvisScreen
import com.example.ui.JarvisViewModel
import com.example.ui.screens.ChatConsoleScreen
import com.example.ui.screens.CommandPaletteDialog
import com.example.ui.screens.CoreReactorScreen
import com.example.ui.screens.GlobeTacticalScreen
import com.example.ui.screens.SettingsAndWakeWordScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            JarvisTheme(themeMode = themeMode) {
                JarvisApp(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val screen: JarvisScreen,
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun JarvisApp(viewModel: JarvisViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val context = LocalContext.current
    var showCommandPalette by remember { mutableStateOf(false) }

    // Request Audio Record Permission for voice interaction & wake word
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted && viewModel.wakeWordEnabled.value) {
            viewModel.toggleWakeWord(true)
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Back button handling
    BackHandler(enabled = currentScreen != JarvisScreen.CORE_REACTOR) {
        viewModel.setScreen(JarvisScreen.CORE_REACTOR)
    }

    val primaryColor = MaterialTheme.colorScheme.primary

    val navItems = listOf(
        NavItem(JarvisScreen.CORE_REACTOR, "Core", Icons.Default.Shield, "nav_core"),
        NavItem(JarvisScreen.CHAT_CONSOLE, "Chat", Icons.Default.Chat, "nav_chat"),
        NavItem(JarvisScreen.ADVANCED_TOOLS, "Tools", Icons.Default.Build, "nav_tools"),
        NavItem(JarvisScreen.TACTICAL_GLOBE, "Globe", Icons.Default.Public, "nav_globe"),
        NavItem(JarvisScreen.SETTINGS_WAKE, "Wake/Cfg", Icons.Default.Settings, "nav_settings")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                contentColor = primaryColor,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, MaterialTheme.colorScheme.outline)
            ) {
                navItems.forEach { item ->
                    val isSelected = currentScreen == item.screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setScreen(item.screen) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = primaryColor,
                            indicatorColor = primaryColor,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(item.testTag)
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentScreen != JarvisScreen.CORE_REACTOR) {
                FloatingActionButton(
                    onClick = { showCommandPalette = true },
                    containerColor = primaryColor,
                    contentColor = Color.Black,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    shape = CircleShape,
                    modifier = Modifier.testTag("command_palette_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Commands",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                JarvisScreen.CORE_REACTOR -> CoreReactorScreen(viewModel = viewModel)
                JarvisScreen.CHAT_CONSOLE -> ChatConsoleScreen(viewModel = viewModel)
                JarvisScreen.ADVANCED_TOOLS -> ToolsScreen(viewModel = viewModel)
                JarvisScreen.TACTICAL_GLOBE -> GlobeTacticalScreen(viewModel = viewModel)
                JarvisScreen.SETTINGS_WAKE -> SettingsAndWakeWordScreen(viewModel = viewModel)
            }

            if (showCommandPalette) {
                CommandPaletteDialog(
                    viewModel = viewModel,
                    onDismiss = { showCommandPalette = false }
                )
            }
        }
    }
}
