package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.VoiceProfile
import com.example.data.storage.PreferencesManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS", appName)
  }

  @Test
  fun `preferences custom wake word storage`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)
    prefs.customWakeWord = "Friday"
    assertEquals("Friday", prefs.customWakeWord)
  }

  @Test
  fun `tts voice profile and pitch rate storage`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = PreferencesManager(context)
    prefs.voiceProfile = VoiceProfile.FRIDAY_TACTICAL
    prefs.speechPitch = 1.18f
    prefs.speechSpeed = 1.12f

    assertEquals(VoiceProfile.FRIDAY_TACTICAL, prefs.voiceProfile)
    assertEquals(1.18f, prefs.speechPitch, 0.01f)
    assertEquals(1.12f, prefs.speechSpeed, 0.01f)
  }
}
